<!DOCTYPE html>
<html lang="es">
<head>
 <meta charset="utf-8">
<title>Dal REPUESTOS reacondicionados encendido Automaticos Bendix Campos Automotores Motor Despiece</title>
<meta name="description" content="Dal Repuesto encendido auto Automaticos impulsores bendix campos carbones portacarbones portadiodos despiece automotor en mataderos  san justo lomas del mirador repuestos de encendido automotor">

<meta name="keywords" content="Dal, Repuesto, encendido, auto, Automaticos, impulsores, bendix, campos, carbones, portacarbones ,portadiodos, despiece, automotor, reacondicionados, reparador, bobinas, bobinas de encendido, arranque, carbones de arranque, alternador
">
 <meta name="viewport"
 content="width=device-width, initial-scale=1, user-scalable=yes">
 <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
 
 <div class="container-fluid" style="margin-top: 100px">
 
  @yield('content')
 </div>
 <style type="text/css">
 .table {
  border-top: 2px solid #ccc;
 
 }
</style>
</body>
</html>