<?php $__env->startSection('content'); ?>
<!-- header -->
            <div class="content" align="center">
                <img src="images/arranque.png" class="img-fluid" alt="Responsive image" >
                <h1>  <strong> Dal</strong></h1>
                <?php echo e($date); ?>

            </div>


<!-- Footer -->
    <footer id="footer" class="pb-4 pt-4">
      <div class="container">
        <div class="row text-center">

    <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('home')); ?>"> Ingresa al Sistema / Registrate</a>
        </div>
      </div>
    </footer>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dal-segunda\resources\views/welcome.blade.php ENDPATH**/ ?>