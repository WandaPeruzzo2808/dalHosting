<h2>Nombre: <?php echo e($name); ?></h2>
<h2>Empresa: <?php echo e($empresa); ?></h2>
<h2>email: <?php echo e($email); ?></h2>
<h2>telefono: <?php echo e($telefono); ?></h2>
<h2>Mensaje: <?php echo e($msg); ?></h2>
<?php /**PATH C:\xampp\htdocs\AppDalFinal\resources\views/email.blade.php ENDPATH**/ ?>