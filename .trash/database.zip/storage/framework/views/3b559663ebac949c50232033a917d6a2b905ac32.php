<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">  
                <div class="card-header">
            <img src="images/loguito.png" >
    
            </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Bienvenido!
                    Esperamos tu compra.
                </div>
            </div>            
        </div>
    </div>
</div>

    <div class="container">
    <p>   </p>
    <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('produs.pdf')); ?>"> Imprimir LISTADO DE PRECIOS </a>

    <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('verlista')); ?>">VER  LISTADO DE PRECIOS</a>
    
    <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('verLibroPedidos')); ?>"> HACE TU PEDIDO </a>
                                                  
    <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(url('/test')); ?>"> CONTACTANOS /  INFORMACION DE CONTACTO </a>

    <a class="btn btn-secondary btn-lg btn-block" href="<?php echo e(route('verPanelAdmin')); ?>">SOLO ADMINISTRADOR</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AppDalFinal\resources\views/home.blade.php ENDPATH**/ ?>