<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
            Actualizar precios
        </div>
        <div class="panel-body">
          <form method="post" action="<?php echo e(route('update-precio-categoria')); ?>">
          <?php echo csrf_field(); ?>
          <div class="col-md-6">
            <select name="categoria" class="form-control">
              <option selected value="todos">Todos</option>
              <option value="AUTOMATICOS NUEVOS">AUTOMATICOS NUEVOS</option>
              <option value="AUTOMATICOS REPARADOS">AUTOMATICOS REPARADOS</option>
              <option value="BOBINAS">BOBINAS</option>
              <option value="CAMPOS NUEVOS">CAMPOS NUEVOS</option>
              <option value="CAMPOS RECAMBIO">CAMPOS RECAMBIO</option>
              <option value="CARBONES">CARBONES</option>
              <option value="DESPIECE VARIOS">DESPIECE VARIOS</option>
              <option value="IMPULSORES">IMPULSORES - BENDIX</option>
              <option value="PLAQUETA PORTACARBONES">PLAQUETA PORTACARBONES</option>
              <option value="PLAQUETA PORTADIODOS">PLAQUETA PORTADIODOS</option>
              <option value="REGULADORES">REGULADORES</option>
              <option value="RULEMANES">RULEMANES</option>
            </select>
          </div>
          <div class="col-md-6">
            <input type="number" name="porcentaje" class="form-control">
          </div>
        </div>
        <div class="panel-footer">
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </div>
    </div>
</div>
</div>

<div class="container">
      <a type="button" class="btn btn-success btn-lg btn-block"  href="<?php echo e(url('/home')); ?>">Volver al inicio</a>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AppDalFinal\resources\views/Producto/actualizaPrecio.blade.php ENDPATH**/ ?>