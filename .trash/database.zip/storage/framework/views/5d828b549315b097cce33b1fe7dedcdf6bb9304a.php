<?php if(Session::has('success')): ?>
	<div class="alert alert-succes" role='alert'>
		<strong><?php echo e(Session::get('success')); ?></strong>
	</div>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\AppDalFinal\resources\views/mensajesFlash.blade.php ENDPATH**/ ?>