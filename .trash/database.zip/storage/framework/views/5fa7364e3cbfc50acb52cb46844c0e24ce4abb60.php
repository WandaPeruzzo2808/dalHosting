<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-body">
          <div class="pull-left"><h3>Lista Productos</h3></div>
          <div class="pull-right">
            <div class="btn-group">
              <a href="<?php echo e(route('producto.create')); ?>" class="btn btn-info" >Añadir Producto</a>
            </div>
          </div>
        </div>
         <div class="table-responsive">
            <table id="mytable" class="table table-bordred table-striped">
             <thead>
               <th>Codigo</th>
               <th>Producto</th>
               <th>Descripcion</th>
               <th>Cod DIPRA</th>
               <th>Cod GV</th>
               <th>Precio</th>
               <th>Precio U$S</th>
               <th>Editar</th>
               <th>Eliminar</th>
             </thead>
             <tbody>
              <?php if($productos->count()): ?>  
              <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
              <tr>
                <td><?php echo e($producto->codigo); ?></td>
                <td><?php echo e($producto->producto); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td><?php echo e($producto->cod_prov1); ?></td>
                <td><?php echo e($producto->cod_prov2); ?></td>
                <td><?php echo e($producto->precio); ?></td>
                <td><?php echo e($producto->precio_uss); ?></td>
                <td><a class="btn btn-primary btn-xs" href="<?php echo e(action('ProductoController@edit', $producto->id)); ?>" ><span class="glyphicon glyphicon-pencil"></span></a></td>
                <td>
                  <form action="<?php echo e(action('ProductoController@destroy', $producto->id)); ?>" method="post">
                   <?php echo e(csrf_field()); ?>

                   <input name="_method" type="hidden" value="DELETE">
 
                   <button class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span></button>
                 </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
               <?php else: ?>
               <tr>
                <td colspan="8">No hay registro !!</td>
              </tr>
              <?php endif; ?>
            </tbody>
 
          </table>
        </div>
      </div>

      <?php echo e($productos->appends(request()->all())->render()); ?>

    </div>

 </div>
</div>
</div>
</div>
</div>
</div>
</div>


<div class="container">
   <a type="button" class="btn btn-success btn-lg btn-block" href="<?php echo e(route('ver-cambio-precio')); ?>">Actualizar Precios</a>
      <a type="button" class="btn btn-success btn-lg btn-block"  href="<?php echo e(url('/home')); ?>">Volver al inicio</a>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AppDalFinal\resources\views/Producto/index.blade.php ENDPATH**/ ?>