<!DOCTYPE html>
<html lang="es">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Styles -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
   <style>
  body { font-family: DejaVu Sans; }
   </style>
</head>
<body>

  <div class="container-fluid">
    <div class="row">
      <img src="images/loguito.png">
  </div>
  <div><p>LISTA DE PRECIOS   -   dalpedidos@gmail.com   -   Tel. 155479-5393   /   2135-5926</p></div>
  <div class="row">
<div class="table-responsive">
        <table id="mytable" class="table table-bordred table-striped" table align="center" border="1" style="font-size:8px;">>
          <thead>
            <tr>
               <th>Codigo</th>
               <th>Producto</th>
               <th>Descripcion</th>
               <th>Cod DIPRA</th>
               <th>Cod GV</th>
               <th>Precio</th>
               <th>Precio U$S</th>
             </tr>
             </thead>

           <tbody>
             <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <tr>
                <td><?php echo e($producto->codigo); ?></td>
                <td><?php echo e($producto->producto); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td><?php echo e($producto->cod_prov1); ?></td>
                <td><?php echo e($producto->cod_prov2); ?></td>
                <td><?php echo e($producto->precio); ?></td>
                <td><?php echo e($producto->precio_uss); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
  </table>
    </div>
    
  </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\AppDalFinal\resources\views/pdf/reportepdf.blade.php ENDPATH**/ ?>