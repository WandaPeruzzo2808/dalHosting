<h2>Nombre: {{$nombre}}</h2>
<h2>Pedido: {{$resumen}}</h2>
<h1>contacto: {{$dato_contacto}}</h1>
<h1>fecha: {{$f_pedido}}</h1>
<h1>Direccion entrega: {{$dire_entrega}}</h1>
<h1>precio: {{$precio}}</h1>