<h2>Nombre: {{$name}}</h2>
<h2>Empresa: {{$empresa}}</h2>
<h2>email: {{$email}}</h2>
<h2>telefono: {{$telefono}}</h2>
<h2>Mensaje: {{$msg}}</h2>
