<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade as PDF;
use App\Producto;

class ProduController extends Controller
{
  public function exportPdf()
  {
  	    $productos = \DB::table('productos')
  	    ->select(['codigo','producto','descripcion','cod_prov1','cod_prov2','precio','precio_uss'])
  	    ->get();
  	    $pdf = PDF::loadView('pdf.reportepdf', compact('productos'));
  		return $pdf->download('precios-dal.pdf');

  }


}
