<?php

use Illuminate\Database\Seeder;

class ProdusTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //factoty(App\Produ::class,250)->create();
    }
}
